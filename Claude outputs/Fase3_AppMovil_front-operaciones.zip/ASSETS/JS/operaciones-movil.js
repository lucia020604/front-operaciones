// =================================================
// OPERACIONES-MOVIL.JS
// Módulo Operaciones de la App Móvil: jornada (Comenzar día/Finalizar),
// datos de la operación asignada, Añadir Hora (con dictado por voz
// simulado), Horario (línea de tiempo con bloqueo de edición cuando ya fue
// revisado desde el sistema) y Asignar Precinto (que registra los
// precintos utilizados directamente en la misma fuente de datos que ya usa
// Precintos > Reporte de Precintos, cerrando el flujo administrador →
// asignación → registro en campo → reporte).
// =================================================

function actualizarHoraStatusBar() {
  const el = document.getElementById('horaStatusBar');
  if (!el) return;
  const ahora = new Date();
  const pad = n => String(n).padStart(2, '0');
  el.textContent = `${pad(ahora.getHours())}:${pad(ahora.getMinutes())}`;
}
actualizarHoraStatusBar();
setInterval(actualizarHoraStatusBar, 15000);

function cerrarSesionMovil() {
  confirmarAccion('¿Deseas cerrar tu sesión?', () => {
    cerrarSesion();
    window.location.href = 'login-movil.html';
  });
}

const DIAS_LARGOS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
const MESES_LARGOS = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

function inicializarOperacionesMovil() {
  const sesion = obtenerUsuarioActual();
  if (!sesion) { window.location.href = 'login-movil.html'; return; }

  const hoy = new Date();
  document.getElementById('headerFechaHoy').textContent =
    `${DIAS_LARGOS[hoy.getDay()]} ${hoy.getDate()} de ${MESES_LARGOS[hoy.getMonth()]}`;

  renderJornada();
  renderOperacionAsignada();
  poblarSelectEstados();
}

// =================================================
// JORNADA (Comenzar día / Finalizar) — simulación de geolocalización al
// marcar cada evento, ver decisión "Simulado con datos demo".
// =================================================
function renderJornada() {
  const sesion = obtenerUsuarioActual();
  const jornada = obtenerJornadaHoy(sesion.usuario);
  const btn = document.getElementById('btnJornada');
  const estadoTexto = document.getElementById('jornadaEstadoTexto');
  const horaTexto = document.getElementById('jornadaHoraTexto');

  if (jornada.fin) {
    estadoTexto.textContent = `Jornada finalizada · inicio ${jornada.inicio}`;
    horaTexto.textContent = jornada.fin;
    btn.textContent = 'Jornada finalizada';
    btn.classList.remove('finalizar');
    btn.disabled = true;
  } else if (jornada.inicio) {
    estadoTexto.textContent = 'Jornada en curso desde';
    horaTexto.textContent = jornada.inicio;
    btn.textContent = 'Finalizar';
    btn.classList.add('finalizar');
    btn.disabled = false;
  } else {
    estadoTexto.textContent = 'Jornada no iniciada';
    horaTexto.textContent = '—';
    btn.textContent = 'Comenzar día';
    btn.classList.remove('finalizar');
    btn.disabled = false;
  }
}

function alternarJornada() {
  const sesion = obtenerUsuarioActual();
  const jornada = obtenerJornadaHoy(sesion.usuario);
  const btn = document.getElementById('btnJornada');
  const pad = n => String(n).padStart(2, '0');

  btn.disabled = true;
  btn.textContent = 'Obteniendo ubicación…';

  setTimeout(() => {
    const ahora = new Date();
    const horaTxt = `${pad(ahora.getHours())}:${pad(ahora.getMinutes())}`;
    const ubicacion = UBICACIONES_DEMO_MOVIL[Math.floor(Math.random() * UBICACIONES_DEMO_MOVIL.length)];

    if (!jornada.inicio) {
      jornada.inicio = horaTxt;
      jornada.ubicacionInicio = ubicacion;
      mostrarToast(`Día iniciado a las ${horaTxt} · ${ubicacion}`);
    } else {
      jornada.fin = horaTxt;
      jornada.ubicacionFin = ubicacion;
      mostrarToast(`Jornada finalizada a las ${horaTxt} · ${ubicacion}`);
    }
    renderJornada();
  }, 700);
}

// =================================================
// OPERACIÓN ASIGNADA
// =================================================
function renderOperacionAsignada() {
  const op = OPERACION_ASIGNADA_MOVIL_DEMO;
  document.getElementById('opCodigo').textContent = op.codigo;
  document.getElementById('opCliente').textContent = op.cliente;
  document.getElementById('opPer').textContent = op.per;
  document.getElementById('opViaje').textContent = op.nroViaje;
  document.getElementById('opTerminal').textContent = op.terminal;
  document.getElementById('opTipoOperacion').textContent = op.operacion;
  document.getElementById('opPersonalBuque').textContent = op.personalBuque;
  document.getElementById('opPersonalPlanta').textContent = op.personalPlanta;
  renderProductosChips();
}

function renderProductosChips() {
  const op = OPERACION_ASIGNADA_MOVIL_DEMO;
  const cont = document.getElementById('opProductosChips');
  cont.innerHTML = op.productos.length
    ? op.productos.map(p => `<span class="op-producto-chip">${p}</span>`).join('')
    : `<span style="font-size:12px;color:var(--gray-400);">Sin productos registrados.</span>`;
}

// =================================================
// AÑADIR HORA (con dictado por voz simulado)
// =================================================
function poblarSelectEstados() {
  const sel = document.getElementById('anadirHoraEstado');
  sel.innerHTML = ESTADOS_OPERACION_MOVIL.map(e => `<option value="${e.clave}">${e.etiqueta}</option>`).join('');
}

function abrirModalAnadirHora() {
  const pad = n => String(n).padStart(2, '0');
  const ahora = new Date();
  document.getElementById('anadirHoraFecha').value = `${ahora.getFullYear()}-${pad(ahora.getMonth() + 1)}-${pad(ahora.getDate())}`;
  document.getElementById('anadirHoraHora').value = `${pad(ahora.getHours())}:${pad(ahora.getMinutes())}`;
  document.getElementById('anadirHoraComentario').value = '';
  document.getElementById('dictadoTexto').textContent = 'Toca el micrófono para dictar el comentario.';
  document.getElementById('btnMicrofono').classList.remove('grabando');

  // Preselecciona el primer estado de la secuencia que aún no tiene fecha
  // registrada, para guiar al colaborador en el orden esperado.
  const siguiente = ESTADOS_OPERACION_MOVIL.find(e => !OPERACION_ASIGNADA_MOVIL_DEMO.estados[e.clave].fecha);
  document.getElementById('anadirHoraEstado').value = siguiente ? siguiente.clave : ESTADOS_OPERACION_MOVIL[0].clave;

  abrirModal('modalAnadirHora');
}

// Dictado por voz simulado: no usa la Web Speech API real (decisión del
// usuario), solo anima el botón y, tras un instante, inserta una frase demo.
function iniciarDictadoSimulado() {
  const btn = document.getElementById('btnMicrofono');
  const texto = document.getElementById('dictadoTexto');
  const campo = document.getElementById('anadirHoraComentario');

  btn.classList.add('grabando');
  texto.textContent = 'Escuchando…';

  setTimeout(() => {
    const frase = FRASES_DICTADO_DEMO[Math.floor(Math.random() * FRASES_DICTADO_DEMO.length)];
    campo.value = campo.value ? `${campo.value} ${frase}` : frase;
    btn.classList.remove('grabando');
    texto.textContent = 'Comentario dictado. Puedes editarlo si lo necesitas.';
  }, 1400);
}

function guardarAnadirHora() {
  const clave = document.getElementById('anadirHoraEstado').value;
  const fechaInput = document.getElementById('anadirHoraFecha');
  const horaInput = document.getElementById('anadirHoraHora');
  const comentario = document.getElementById('anadirHoraComentario').value.trim();

  if (!fechaInput.value) { mostrarErrorCampo(fechaInput, 'Selecciona una fecha'); return; }
  if (!horaInput.value) { mostrarErrorCampo(horaInput, 'Selecciona una hora'); return; }

  const [anio, mes, dia] = fechaInput.value.split('-');
  OPERACION_ASIGNADA_MOVIL_DEMO.estados[clave] = {
    fecha: `${dia}/${mes}/${anio}`,
    hora: horaInput.value,
    comentario
  };

  cerrarModal('modalAnadirHora');
  mostrarModalGuardado('crear', null, () => {});
}

// =================================================
// HORARIO — línea de tiempo de estados
// =================================================
function abrirModalHorario() {
  const op = OPERACION_ASIGNADA_MOVIL_DEMO;
  document.getElementById('horarioLockNota').style.display = op.revisadoPorSistema ? 'flex' : 'none';
  renderTimelineEstados();
  abrirModal('modalHorario');
}

function renderTimelineEstados() {
  const op = OPERACION_ASIGNADA_MOVIL_DEMO;
  const bloqueado = op.revisadoPorSistema;
  const cont = document.getElementById('timelineEstados');

  cont.innerHTML = ESTADOS_OPERACION_MOVIL.map(e => {
    const dato = op.estados[e.clave];
    const completado = !!dato.fecha;
    return `
      <div class="timeline-item ${completado ? 'completado' : ''}">
        <div class="timeline-punto">
          ${completado
            ? '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6 9 17l-5-5"/></svg>'
            : ''}
        </div>
        <div class="timeline-cuerpo">
          <div class="timeline-etiqueta">${e.etiqueta}</div>
          <div class="timeline-detalle">${completado ? `${dato.fecha} · ${dato.hora}` : 'Pendiente de registrar'}</div>
          ${dato.comentario ? `<div class="timeline-comentario">"${dato.comentario}"</div>` : ''}
          ${completado && !bloqueado ? `<button class="movil-btn-secundario" style="height:32px;margin-top:6px;font-size:11.5px;" onclick="editarEstadoHorario('${e.clave}')">Editar</button>` : ''}
        </div>
      </div>`;
  }).join('');
}

// Edición puntual de un estado ya registrado (equivalente de campo al mismo
// patrón de edición limitada usado en Precintos/Gastos): solo disponible si
// el horario no fue revisado desde el sistema.
function editarEstadoHorario(clave) {
  const dato = OPERACION_ASIGNADA_MOVIL_DEMO.estados[clave];
  const nuevoComentario = prompt('Editar comentario:', dato.comentario || '');
  if (nuevoComentario === null) return;
  dato.comentario = nuevoComentario.trim();
  renderTimelineEstados();
  mostrarToast('Comentario actualizado.');
}

// =================================================
// ASIGNAR PRECINTO — usa el mismo rango de la Asignación de Precintos hecha
// desde el sistema (ASIGNACIONES_PRECINTOS_DEMO) y escribe el uso reportado
// directamente en GENERAR_REGISTROS_PRECINTOS_DEMO, la misma fuente que
// muestra Precintos > Reporte de Precintos > Detalle.
// =================================================
function generarRangoPrecintos(desde, hasta) {
  const m = desde.match(/^([A-Za-z]*-?)(\d+)$/);
  const mHasta = hasta.match(/^([A-Za-z]*-?)(\d+)$/);
  if (!m || !mHasta) return [];
  const prefijo = m[1];
  const largo = m[2].length;
  const ini = parseInt(m[2], 10);
  const fin = parseInt(mHasta[2], 10);
  const lista = [];
  for (let i = ini; i <= fin; i++) {
    lista.push(prefijo + String(i).padStart(largo, '0'));
  }
  return lista;
}

function abrirModalAsignarPrecinto() {
  const op = OPERACION_ASIGNADA_MOVIL_DEMO;
  const asignacion = ASIGNACIONES_PRECINTOS_DEMO.find(a => a.pers.includes(op.per));
  const registro = obtenerGenerarRegistroPorPer(op.per);

  const sinDatos = document.getElementById('asignarPrecintoSinDatos');
  const form = document.getElementById('asignarPrecintoForm');
  const btnGuardar = document.getElementById('btnGuardarAsignarPrecinto');

  if (!asignacion || !registro) {
    sinDatos.style.display = 'block';
    form.style.display = 'none';
    btnGuardar.style.display = 'none';
    abrirModal('modalAsignarPrecinto');
    return;
  }
  sinDatos.style.display = 'none';
  form.style.display = 'block';
  btnGuardar.style.display = '';

  const rango = generarRangoPrecintos(asignacion.numDesde, asignacion.numHasta);
  const usados = registro.detalle.map(d => d.precinto);
  const disponibles = rango.filter(p => !usados.includes(p));

  const selPrecinto = document.getElementById('asignarPrecintoNumero');
  selPrecinto.innerHTML = disponibles.length
    ? disponibles.map(p => `<option value="${p}">${p}</option>`).join('')
    : `<option value="">No quedan precintos disponibles en este rango</option>`;

  const sesion = obtenerUsuarioActual();
  const posiblesColaboradores = [op.personalBuque, op.personalPlanta]
    .filter(nombre => nombre && nombre !== `${sesion.nombre} ${sesion.apellido}`);
  const selColab = document.getElementById('asignarPrecintoColaborador2');
  selColab.innerHTML = posiblesColaboradores.map(n => `<option value="${n}">${n}</option>`).join('');

  document.getElementById('asignarPrecintoViaje').value = op.nroViaje;
  const pad = n => String(n).padStart(2, '0');
  const ahora = new Date();
  document.getElementById('asignarPrecintoFecha').value = `${ahora.getFullYear()}-${pad(ahora.getMonth() + 1)}-${pad(ahora.getDate())}`;
  document.getElementById('asignarPrecintoObservacion').value = '';
  document.getElementById('asignarPrecintoUsados').textContent =
    `${usados.length} de ${rango.length} precintos del rango ${asignacion.numDesde} - ${asignacion.numHasta} ya fueron registrados.`;

  abrirModal('modalAsignarPrecinto');
}

function guardarAsignarPrecinto() {
  const op = OPERACION_ASIGNADA_MOVIL_DEMO;
  const registro = obtenerGenerarRegistroPorPer(op.per);
  const precinto = document.getElementById('asignarPrecintoNumero').value;
  const colaborador2 = document.getElementById('asignarPrecintoColaborador2').value;
  const viajeInput = document.getElementById('asignarPrecintoViaje');
  const fechaInput = document.getElementById('asignarPrecintoFecha');
  const observacion = document.getElementById('asignarPrecintoObservacion').value.trim();

  if (!precinto) { mostrarToast('No hay un precinto disponible para registrar.'); return; }
  if (!viajeInput.value.trim()) { mostrarErrorCampo(viajeInput, 'Ingresa el N° de viaje'); return; }
  if (!fechaInput.value) { mostrarErrorCampo(fechaInput, 'Selecciona una fecha'); return; }

  const sesion = obtenerUsuarioActual();
  const [anio, mes, dia] = fechaInput.value.split('-');

  registro.detalle.push({
    colaborador1: `${sesion.nombre} ${sesion.apellido}`,
    colaborador2: colaborador2 || '',
    precinto,
    viaje: viajeInput.value.trim(),
    fecha: `${dia}/${mes}/${anio}`,
    observacion
  });

  cerrarModal('modalAsignarPrecinto');
  mostrarModalGuardado('crear', 'El precinto quedará visible en Precintos > Reporte de Precintos.', () => {});
}

// =================================================
// ACTUALIZAR PRODUCTO
// =================================================
function abrirModalActualizarProducto() {
  document.getElementById('nuevoProductoInput').value = '';
  renderChipsActualizarProducto();
  abrirModal('modalActualizarProducto');
}

function renderChipsActualizarProducto() {
  const op = OPERACION_ASIGNADA_MOVIL_DEMO;
  const cont = document.getElementById('actualizarProductoChips');
  cont.innerHTML = op.productos.length
    ? op.productos.map((p, i) => `
        <span class="op-producto-chip">${p}
          <button type="button" onclick="quitarProductoOperacion(${i})" title="Quitar">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
          </button>
        </span>`).join('')
    : `<span style="font-size:12px;color:var(--gray-400);">Sin productos registrados.</span>`;
}

function agregarProductoOperacion() {
  const input = document.getElementById('nuevoProductoInput');
  const valor = input.value.trim();
  if (!valor) { mostrarErrorCampo(input, 'Ingresa un producto'); return; }
  if (OPERACION_ASIGNADA_MOVIL_DEMO.productos.includes(valor)) { mostrarToast('Ese producto ya está registrado.'); return; }

  OPERACION_ASIGNADA_MOVIL_DEMO.productos.push(valor);
  input.value = '';
  renderChipsActualizarProducto();
  renderProductosChips();
}

function quitarProductoOperacion(indice) {
  OPERACION_ASIGNADA_MOVIL_DEMO.productos.splice(indice, 1);
  renderChipsActualizarProducto();
  renderProductosChips();
}

document.addEventListener('DOMContentLoaded', inicializarOperacionesMovil);
