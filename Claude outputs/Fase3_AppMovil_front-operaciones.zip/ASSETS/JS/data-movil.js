// =================================================
// DATA-MOVIL.JS
// Fuente única de datos de la App Móvil (prototipo sin backend). La app
// móvil reutiliza el mismo login y la misma sesión que el sistema web
// (USUARIOS_DEMO / sessionStorage.sesionUsuario) — es el mismo sistema,
// visto desde el dispositivo del colaborador en campo.
//
// Los datos de la operación asignada se modelan aquí como un set demo
// independiente (mismo formato de PER, buque, terminal y nombres de estado
// que ya usa el resto del sistema) en lugar de acoplarse a OPERACIONES_DEMO
// de Seguimiento de Operaciones, para no modificar código fuera del
// alcance pedido en esta fase (solo App Móvil).
// =================================================

// Datos adicionales de perfil (Área, DNI) por usuario — el resto de datos
// del Perfil (Nombre, Apellido, Rol, Celular) ya están en USUARIOS_DEMO.
const PERFIL_MOVIL_EXTRA_DEMO = {
  'e.allccaco': { area: 'Operaciones', dni: '45120384' },
  'r.bravo':    { area: 'Operaciones', dni: '46220157' },
  'j.gomez':    { area: 'Operaciones', dni: '41985023' }
};

// Direcciones demo que devuelve "Actualizar Ubicación" (simulación de
// geolocalización — ver decisión del usuario: sin APIs reales del navegador).
const UBICACIONES_DEMO_MOVIL = [
  'Av. Costanera 245, Supe Puerto, Barranca',
  'Muelle Fiscal N.° 2, Supe Puerto, Barranca',
  'Jr. Los Pescadores 118, Supe, Barranca'
];

// Frases demo que devuelve el dictado por voz simulado (botón de micrófono).
const FRASES_DICTADO_DEMO = [
  'Operación en curso sin novedades.',
  'Demora por espera de marea, se reanuda en 30 minutos.',
  'Se coordina con el buque el inicio de la siguiente etapa.'
];

// Secuencia de estados de la operación (coincide con las columnas ya usadas
// en Reporte Mensual de Cabotaje: Eta, Arriba, Fondea, Amarre inicio, Inicia,
// Termina, Firma de Documentos, Zarpe).
const ESTADOS_OPERACION_MOVIL = [
  { clave: 'eta', etiqueta: 'Eta' },
  { clave: 'arriba', etiqueta: 'Arriba' },
  { clave: 'fondea', etiqueta: 'Fondea' },
  { clave: 'amarreInicio', etiqueta: 'Amarre inicio' },
  { clave: 'inicia', etiqueta: 'Inicia' },
  { clave: 'termina', etiqueta: 'Termina' },
  { clave: 'firmaDocumentos', etiqueta: 'Firma de Documentos' },
  { clave: 'zarpe', etiqueta: 'Zarpe' }
];

// Operación asignada al colaborador en sesión (demo: una sola operación
// activa, como caso representativo del módulo).
const OPERACION_ASIGNADA_MOVIL_DEMO = {
  codigo: 'OP-2026-041',
  cliente: 'Naviera del Sur',
  per: 'PER/09461-25',
  nroViaje: 'V-2201',
  terminal: 'Supe',
  operacion: 'Loading',
  personalBuque: 'Edward Allccaco',
  personalPlanta: 'Rudy Bravo Flores',
  productos: ['LNG'],
  // admiVisadoPorSistema: si el área administrativa ya marcó "Revisado" desde
  // el sistema, el horario queda bloqueado para edición desde el móvil.
  revisadoPorSistema: false,
  estados: {
    eta: { fecha: '06/07/2026', hora: '06:00', comentario: '' },
    arriba: { fecha: '06/07/2026', hora: '08:10', comentario: '' },
    fondea: { fecha: '', hora: '', comentario: '' },
    amarreInicio: { fecha: '', hora: '', comentario: '' },
    inicia: { fecha: '', hora: '', comentario: '' },
    termina: { fecha: '', hora: '', comentario: '' },
    firmaDocumentos: { fecha: '', hora: '', comentario: '' },
    zarpe: { fecha: '', hora: '', comentario: '' }
  }
};

// Jornada diaria (Comenzar día / Finalizar) por usuario y fecha — reinicia
// en cada carga de página como el resto del prototipo (sin backend).
const JORNADAS_MOVIL_DEMO = {};

function obtenerFechaHoyISO() {
  return new Date().toISOString().slice(0, 10);
}

function obtenerJornadaHoy(usuario) {
  const clave = `${usuario}_${obtenerFechaHoyISO()}`;
  if (!JORNADAS_MOVIL_DEMO[clave]) {
    JORNADAS_MOVIL_DEMO[clave] = { inicio: null, fin: null };
  }
  return JORNADAS_MOVIL_DEMO[clave];
}
