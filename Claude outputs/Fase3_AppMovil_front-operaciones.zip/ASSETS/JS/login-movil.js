// =================================================
// LOGIN-MOVIL.JS
// Inicio de Sesión de la App Móvil. Reutiliza exactamente el mismo origen de
// datos y de sesión que el login de escritorio (USUARIOS_DEMO,
// obtenerUsuarioPorLogin, guardarSesionUsuario / sessionStorage.sesionUsuario)
// — es el mismo sistema, visto desde el dispositivo del colaborador en
// campo, por lo que un usuario que ya existe en Configuración > Usuarios
// puede iniciar sesión aquí con las mismas credenciales.
//
// A diferencia del login de escritorio, la app móvil no maneja el flujo de
// contraseña por vencer/vencida (fuera del alcance de esta fase): si la
// contraseña no está vigente, igual se concede el acceso, priorizando que
// el colaborador en campo no quede bloqueado sin poder registrar su
// operación.
// =================================================

const DESTINO_LOGIN_MOVIL = '../MOVIL/operaciones-movil.html';

function actualizarHoraStatusBar() {
  const el = document.getElementById('horaStatusBar');
  if (!el) return;
  const ahora = new Date();
  const pad = n => String(n).padStart(2, '0');
  el.textContent = `${pad(ahora.getHours())}:${pad(ahora.getMinutes())}`;
}
actualizarHoraStatusBar();
setInterval(actualizarHoraStatusBar, 15000);

function toggleCampoPass(inputId, iconId) {
  const input = document.getElementById(inputId);
  const icon = document.getElementById(iconId);
  if (input.type === 'password') {
    input.type = 'text';
    icon.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
  } else {
    input.type = 'password';
    icon.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
  }
}

function handleLoginMovil(e) {
  e.preventDefault();
  const btn = document.getElementById('loginMovilBtn');
  const btnTexto = document.getElementById('loginMovilBtnTexto');
  const err = document.getElementById('errorMsgMovil');
  err.classList.remove('show');

  btn.disabled = true;
  btnTexto.textContent = 'Ingresando…';

  setTimeout(() => {
    const user = document.getElementById('usuarioMovil').value.trim().toLowerCase();
    const pass = document.getElementById('passwordMovil').value;
    const encontrado = obtenerUsuarioPorLogin(user, pass);

    if (!encontrado) {
      btn.disabled = false;
      btnTexto.textContent = 'Iniciar Sesión';
      err.classList.add('show');
      return;
    }

    guardarSesionUsuario(encontrado);
    window.location.href = DESTINO_LOGIN_MOVIL;
  }, 900);
}
